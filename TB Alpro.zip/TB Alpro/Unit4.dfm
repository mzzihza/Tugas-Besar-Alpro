object Form4: TForm4
  Left = 794
  Top = 174
  Width = 437
  Height = 500
  Caption = 'Form4'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object GroupBox1: TGroupBox
    Left = 24
    Top = 16
    Width = 345
    Height = 377
    Caption = 'GroupBox1'
    TabOrder = 0
    object Label1: TLabel
      Left = 40
      Top = 24
      Width = 85
      Height = 13
      Caption = 'Form Pembayaran'
    end
    object Label2: TLabel
      Left = 8
      Top = 56
      Width = 54
      Height = 13
      Caption = 'Pelanggan:'
    end
    object Label3: TLabel
      Left = 8
      Top = 88
      Width = 44
      Height = 13
      Caption = 'Layanan:'
    end
    object Label4: TLabel
      Left = 8
      Top = 120
      Width = 76
      Height = 13
      Caption = 'Harga Layanan:'
    end
    object Label5: TLabel
      Left = 8
      Top = 152
      Width = 92
      Height = 13
      Caption = 'Produk Digunakan:'
    end
    object Label6: TLabel
      Left = 128
      Top = 56
      Width = 32
      Height = 13
      Caption = 'urfyugr'
    end
    object Label7: TLabel
      Left = 131
      Top = 88
      Width = 23
      Height = 13
      Caption = 'jhbdr'
    end
    object Label8: TLabel
      Left = 128
      Top = 120
      Width = 31
      Height = 13
      Caption = 'jyegfer'
    end
    object Label9: TLabel
      Left = 131
      Top = 152
      Width = 47
      Height = 13
      Caption = 'jyegfweyg'
    end
    object Label10: TLabel
      Left = 8
      Top = 208
      Width = 318
      Height = 13
      Caption = 
        '----------------------------------------------------------------' +
        '------------------------------------------'
    end
    object Label11: TLabel
      Left = 8
      Top = 248
      Width = 27
      Height = 13
      Caption = 'Total:'
    end
    object Label12: TLabel
      Left = 280
      Top = 248
      Width = 29
      Height = 13
      Caption = 'jysgvjr'
    end
    object Label13: TLabel
      Left = 8
      Top = 280
      Width = 53
      Height = 13
      Caption = 'Bayar (Rp):'
    end
    object Label14: TLabel
      Left = 8
      Top = 184
      Width = 51
      Height = 13
      Caption = 'Antrian ke-'
    end
    object Label15: TLabel
      Left = 136
      Top = 184
      Width = 23
      Height = 13
      Caption = 'hsfcf'
    end
    object Edit1: TEdit
      Left = 136
      Top = 272
      Width = 177
      Height = 21
      TabOrder = 0
    end
    object Button1: TButton
      Left = 16
      Top = 304
      Width = 89
      Height = 25
      Caption = 'Bayar'
      TabOrder = 1
      OnClick = Button1Click
    end
    object ListBox1: TListBox
      Left = 112
      Top = 304
      Width = 217
      Height = 25
      ItemHeight = 13
      TabOrder = 2
    end
    object Button2: TButton
      Left = 24
      Top = 336
      Width = 81
      Height = 33
      Caption = 'Button2'
      TabOrder = 3
      OnClick = Button2Click
    end
  end
end
